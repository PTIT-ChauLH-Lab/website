<?php 

// Load main style css
function academix_child_custom_page_style(){
	wp_enqueue_style( 'academix-parent-style', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'academix-child-style', get_stylesheet_directory_uri() . '/style.css', array( 'academix-parent-style' ) );
}
add_action( 'wp_enqueue_scripts', 'academix_child_custom_page_style', 155 );